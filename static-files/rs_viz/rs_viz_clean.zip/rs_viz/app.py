#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Dash-Cytoscape app for exploring membership election patters in the early Royal Society
with search dropdown, info panel,
ancestor/descendant highlighting, and adjustable layout.
"""
import dash
from dash import html, dcc
from dash.dependencies import Input, Output
import dash_cytoscape as cyto
import networkx as nx
import pandas as pd
from datetime import datetime, date
import ast
import math
import random
import re
import os
from dash import no_update


#%% Loading File Directory 

DATA_DIR = os.path.join(os.path.dirname(__file__), "data")

#%% Load dataframes

# fellows_df = pd.read_csv(os.path.join(DATA_DIR, "fellows.csv"))

full_data = pd.read_csv(os.path.join(DATA_DIR, "Public_RS_data_ConfirmedMatches.csv")), 
   
refined_data = pd.read_csv(os.path.join(DATA_DIR, "Public_RS_Proposer_Data_Cleaned&Graphable.csv"))

demo_data = pd.read_csv(os.path.join(DATA_DIR, "Public_RS_data_cleanMembershipColumn.csv"))
    
metric_data = pd.read_csv(os.path.join(DATA_DIR, "Public_Complete_RS_Graph_Metrics_MetaData.csv"))
    
office_data = pd.read_csv(os.path.join(DATA_DIR, "Public_RS_Graph_Metrics_MetaData_with_Office_Data.csv"))
   
#%%
# Build directed graph

def parse_proposers(cell):
    """
    Parse a raw cell into a list of proposer IDs.
    Handles mismatched quotes/brackets by manual splitting on commas.
    """
    import pandas as _pd
    # Drop NaN or None
    if cell is None or (_pd.isna(cell) and not isinstance(cell, str)):
        return []
    text = str(cell).strip()
    # Remove outer brackets if present
    if text.startswith('[') and text.endswith(']'):
        text = text[1:-1]
    # Split on commas
    parts = [part.strip() for part in text.split(',')]
    clean = []
    for p in parts:
        # Strip stray quotes and whitespace
        pid = p.strip(" '\"\[\]")
        # Skip empty or placeholder entries
        if not pid or pid.lower() in ('nan', 'none'):
            continue
        clean.append(pid)
    return clean


refined_data['proposers_list'] = refined_data['hand_cleaned_stage2_matches'].apply(parse_proposers)
df_exp = refined_data.explode('proposers_list')
df_exp = df_exp[df_exp['proposers_list'] != '']

G = nx.DiGraph()
for _, row in df_exp.iterrows():
    G.add_edge(row['proposers_list'], row['PersonID'])
# remove nan and isolates
G.remove_nodes_from([n for n in G.nodes() if isinstance(n, float) and math.isnan(n)])
G.remove_nodes_from(list(nx.isolates(G)))
# attach dates





#%% Adding metadata as node attributes

# Adding dates
all_nodes = list(G.nodes())
date_map = {
    n: metric_data.loc[metric_data.personID == n, 'electiondate'].iat[0]
    if n in set(metric_data.personID)
    else datetime(1700,1,1)      # default for proposers
    for n in all_nodes
}
nx.set_node_attributes(G, date_map, 'date')

# Adding Authorized Name 
demo_data.set_index("personID")
name_map = pd.Series(demo_data.personname.values, index=demo_data.personID).to_dict()
nx.set_node_attributes(G, name_map,   'name')

# Adding EMLO ID
EMLOid_map = pd.Series(metric_data.EMLOPersonID.values, index=metric_data.personID).to_dict()
nx.set_node_attributes(G, EMLOid_map, "EMLOid")

# Adding Royal Society ID 
RScode_map = pd.Series(metric_data.code.values, index=metric_data.personID).to_dict()
nx.set_node_attributes(G, RScode_map, "RScode")

# Adding In-Degree 
indegree_map = pd.Series(metric_data.InDegree.values, index=metric_data.personID).to_dict()
nx.set_node_attributes(G, indegree_map, "indegree")

# Adding Out-Degree
outdegree_map = pd.Series(metric_data.OutDegree.values, index=metric_data.personID).to_dict()
nx.set_node_attributes(G, outdegree_map, "outdegree")

# Adding Geneology Length 
genlength_map = pd.Series(metric_data.GeneologyLength.values, index=metric_data.personID).to_dict()
nx.set_node_attributes(G, genlength_map, "genlength")

# Adding Total Descendants 
desc_map = pd.Series(metric_data.TotalDecendants.values, index=metric_data.personID).to_dict()
nx.set_node_attributes(G, desc_map, "totaldesc")

# Adding Total Ancestors 
ance_map = pd.Series(metric_data.TotalAncestors.values, index=metric_data.personID).to_dict()
nx.set_node_attributes(G, ance_map, "totalance")

# Adding Nationaluity 
nat_series = demo_data.set_index('personID')['nationality'] \
                      .fillna('Unknown')
nat_map = nat_series.to_dict()
nx.set_node_attributes(G, nat_map, "nationality")

# Adding Membership Type 
fel_map = pd.Series(demo_data.membershiptype.values, index=demo_data.personID).to_dict()
nx.set_node_attributes(G, fel_map, "membershiptype")


# Adding decending Generations


def add_descending_gen_att(G, metric_data, max_k=6):
    """
    For each k from 1..max_k, read the 
    "{k}thGenDescendants" column out of mapping_df
    and set a node attribute of that exact name on G.
    """
    for k in range(1, max_k+1):
        col = f"{k}thGenDescendants"
        if col not in metric_data.columns:
            continue

        # This gives { node_id: [desc1,desc2,…], … }
        gen_map = dict(zip(
            metric_data['personID'],
            metric_data[col]
        ))

        # Attach *exactly* that attribute name to each node
        nx.set_node_attributes(G, gen_map, f"Generation {k} Descendants")

    return G

G = add_descending_gen_att(G, metric_data, max_k=6)


# Adding ascending generations 
def add_ascending_gen_att(G, metric_data, max_k=6):
    """
    For each k from 1..max_k, read the 
    "{k}thGenDescendants" column out of mapping_df
    and set a node attribute of that exact name on G.
    """
    for k in range(1, max_k+1):
        col = f"{k}thGenAncestors"
        if col not in metric_data.columns:
            continue

        # This gives { node_id: [desc1,desc2,…], … }
        gen_map = dict(zip(
            metric_data['personID'],
            metric_data[col]
        ))

        # Attach *exactly* that attribute name to each node
        nx.set_node_attributes(G, gen_map, f"Generaation {k} Ancestors")

    return G

G = add_ascending_gen_att(G, metric_data, max_k=6)


# Adding Display Name Attribute 

def make_display_name(pid: str) -> str:
    """
    Turn personID like:
      Foo_Bar_1623_1687 
      Foo_Bar_c_1623_1687 
      Foo_Bar_1623 
      Foo_Bar_fl_1723
      Foo_Bar 
    into:
      'Foo, Bar 1623-1687'
      'Foo, Bar 1623'
      'Foo, Bar'
    """

    # 1) Regex out the name core and the year-block(s) (and optional '_c'/'_fl' before them)
    m = re.match(r'^(.*?)(?:_(?:c|fl))?_([0-9]{3,4}(?:_[0-9]{3,4})?)$', pid)
    if m:
        name_core = m.group(1)
        years_raw = m.group(2)              # e.g. "1623_1687" or "1623"
        parts = years_raw.split('_')
        if len(parts) == 2:
            year_text = f"{parts[0]}-{parts[1]}"
        else:
            year_text = parts[0]
    else:
        # no years found
        name_core = pid
        year_text = None

    # 2) Split on first underscore: last vs rest
    last, sep, rest = name_core.partition('_')
    rest = rest.replace('_',' ') if sep else ''

    # 3) Build display name
    if rest:
        display = f"{last}, {rest}"
    else:
        display = last

    # 4) Append years if we have them
    if year_text:
        display = f"{display} {year_text}"

    return display

display_map = { n: make_display_name(n) for n in G.nodes() }
nx.set_node_attributes(G, display_map, 'displayName')
#%% Layout calculations 
# Compute forest layout X

def forest_layout(G, dx=1.5):
    pos = {}
    x_offset = 0
    for comp in nx.weakly_connected_components(G):
        roots = [n for n in comp if G.in_degree(n) == 0] or [next(iter(comp))]
        for root in roots:
            def recurse(u, x):
                pos[u] = (x, 0)
                children = list(G.successors(u))
                for i, c in enumerate(children):
                    shift = (i - (len(children)-1)/2)*dx
                    recurse(c, x+shift)
            recurse(root, x_offset)
        # width from placed nodes only
        xs = [pos[n][0] for n in comp if n in pos]
        width = (max(xs)-min(xs)) if xs else dx
        x_offset += width + dx
    return pos

tree_xy = forest_layout(G, dx=2.5)
x_tree = {n: tree_xy[n][0] for n in G.nodes() if n in tree_xy}

# Parse dates and combine positions


def parse_date(raw):
    default = datetime(1700, 1, 1)

    # 1) Catch nulls
    if raw is None or (isinstance(raw, float) and pd.isna(raw)):
        return default

    # 2) Already a datetime?
    if isinstance(raw, datetime):
        return raw

    s = str(raw).strip()

    # 3) Exact DD/MM/YYYY format
    try:
        return datetime.strptime(s, "%d/%m/%Y")
    except ValueError:
        pass

    # 4) ISO fallback
    try:
        return datetime.fromisoformat(s)
    except Exception:
        pass

    # 5) Pandas with dayfirst
    ts = pd.to_datetime(s, dayfirst=True, errors="coerce")
    if not pd.isna(ts):
        return ts.to_pydatetime()

    # 6) Give up
    return default



dates = {n: parse_date(d) for n, d in nx.get_node_attributes(G, 'date').items()}
min_date = min(dates.values())



default = datetime(1700, 1, 1)
bad = [n for n, dt in dates.items() if dt == datetime(1700,1,1)]




def combined_positions(dx=200, dy=100, jitter=0.1):
    pos = {}
    for n in G.nodes():
        base_x = x_tree.get(n, 0)*dx
        off = random.uniform(-jitter*dx, jitter*dx)
        y_val = (dates[n] - min_date).days * dy
        pos[n] = {'x': base_x+off, 'y': -y_val}
    return pos

pos = combined_positions()

#%% Creating President Terms Dictionary 
office_data = office_data.set_index("personID")

president_terms = {}

president_names = {}

for pid, row in office_data.iterrows(): 
    start = row["presidentstart"]
    end   = row["presidentend"]
    if pd.isna(start) or pd.isna(end):
        continue
    start = parse_date(start).date()
    end   = parse_date(end).date()
    if pd.isna(start) or pd.isna(end):
        continue

    cohort = [n for n, dt in dates.items() if start < dt.date() <= end]
    # 1) Strip off the trailing "_YYYY_YYYY"
    name_only = re.sub(r'_[0-9]{3,4}_[0-9]{3,4}$', '', pid)
    # 2) Split into last-name vs. the rest
    last, sep, rest = name_only.partition('_')
    # 3) Replace remaining underscores in the rest with spaces
    rest = rest.replace('_', ' ') if sep else ''
    # 4) Build the final nice_name with a comma after the last name
    if rest:
        nice_name = f"{last}, {rest}" 
    else: 
        nice_name = last
    # 5) Append the presidency years as before
    label = f"Pres. {nice_name}, {start.year}-{end.year}" 
    
    president_names[label] = pid
    president_terms[label] = cohort


flat_options = []
# all individuals
flat_options += [
    {"label": f"Member: {G.nodes[n]['displayName']}", "value": n}
    for n in sorted(G.nodes())
]

# all presidential cohorts
flat_options += [
    {"label": f"President term: {term}", "value": term}
    for term in president_terms
]

#%% Creating Secretary Terms Dictionary 
office_data = office_data.rename(columns=str.strip).rename(columns=str.lower)
def parse_date_to_date(raw):
    dt = parse_date(raw)          # your existing routine
    if isinstance(dt, datetime):  
        return dt.date()          # strip off the time component
    if isinstance(dt, date):      
        return dt                 # leave plain dates alone
    return None


true_dates = {
    n: ddate
    for n, ddate in (
        (n, parse_date_to_date(d))
        for n, d in nx.get_node_attributes(G, "date").items()
    )
    if ddate is not None            # drop any unparsed / missing ones
}



secretary_terms = {}

secretary_names = {}

for pid, row in office_data.iterrows():
    
    cohorts = []
    
    # First term
    start = row.get("secretarystart")
    end   = row.get("secretaryend")
    
    if pd.notna(start) and pd.notna(end):
        s1 = parse_date_to_date(parse_date(start))
        e1 = parse_date_to_date(parse_date(end))
        if not (pd.isna(s1) or pd.isna(e1)):
            cohorts.extend([n for n, dt in true_dates.items() 
                            if (not pd.isna(dt)) and (s1 < dt <= e1)
                            ])
            
    # Second term (non-consecutive)
    start2 = row.get('secretarystart2')
    end2   = row.get('secretaryend2')
    if pd.notna(start2) and pd.notna(end2):
        s2 = parse_date_to_date(parse_date(start2))
        e2 = parse_date_to_date(parse_date(end2))
        if not (pd.isna(s2) or pd.isna(e2)):
            cohorts.extend([n for n, dt in true_dates.items() 
                            if (not pd.isna(dt)) and (s2 < dt < e2)
                            ])
            

    # Dedupe
    cohort = list(dict.fromkeys(cohorts))  

    # Debug check for fellows who served twice
    if len(cohorts) != len(cohort):
        print(f"Dup found for {pid}: original {len(cohorts)}, deduped {len(cohort)}")

    if cohort:
        # make nice label
        core = re.sub(r'_[0-9]{3,4}(?:_[0-9]{3,4})?$', '', pid)
        last, sep, rest = core.partition('_')
        rest = rest.replace('_',' ') if sep else ''
        nice = f"{last}, {rest}" if rest else last
        if pd.isna(start2): 
            label = f"Sec. {nice}, {start} to {end}"
        else: 
            label = f"Sec. {nice}, {start} to {end} & {start2} to {end2}"
        
        secretary_names[label] = pid
        
        secretary_terms[label] = cohort
        

# all secretary cohorts
flat_options += [
    {"label": f"Secretary term: {term}", "value": term}
    for term in secretary_terms
]

#%% Creating List of Founding Members

founders = []
for pid, row in office_data.iterrows():        # pid is already the index
    if str(row.get("founder?", "")).strip().lower() == "yes":
        if pid in G.nodes():
            founders.append((pid, G.nodes[pid]["displayName"]))

# unpack into two helper structures
founder_ids = [pid for pid, name in founders]
founder_labels = { pid: name for pid, name in founders }

flat_options = [
    # 1) every individual
    {"label": f"Member: {G.nodes[n]['displayName']}", "value": n}
    for n in sorted(G.nodes())
] + [
    # 2) every president‐term
    {"label": f"President term: {term}", "value": term}
    for term in president_terms
] + [
    # 3) every secretary‐term
    {"label": f"Secretary term: {term}", "value": term}
    for term in secretary_terms
]

# 4) then a single opt-group for founders
# remove any existing Founder entries
flat_options = [
    o for o in flat_options
    if not o["label"].startswith("Founder:")
]

# append one single “Founders” option
flat_options.append({
    "label": "Founders",
    "value": "Founders"
})

#%% Creating a List of foriegn members

foreign_fellows = [
    (node, G.nodes[node]["displayName"])
    for node in G.nodes()
    if G.nodes[node].get('nationality', '').strip() not in {'British','English','Unknown'}
]

foreign_ids = [pid for pid, name in foreign_fellows]
foreign_labels = {pid: name for pid, name in foreign_fellows}

flat_options.append({
    'label': "Foreign Fellows", 
    "value": "Foreign Fellows"})

#%% Creating a List of members of domestic origin

domestic_fellows = [
    (node, G.nodes[node]["displayName"])
    for node in G.nodes()
    if G.nodes[node].get("nationality", '').strip() in {'British', 'English'}
]

domestic_ids = [pid for pid, name in domestic_fellows]
domestic_labels = {pid: name for pid, name in domestic_fellows}

flat_options.append({
    'label': "Domestic Fellows",
    "value": "Domestic Fellows"})

#%% Creating a list of members of unknown national origin

unknown_fellows = [
    (node, G.nodes[node]["displayName"])
    for node in G.nodes()
    if G.nodes[node].get("nationality", '').strip() in {'Unknown'}
]

unknown_ids = [pid for pid, name in unknown_fellows]
unknown_labels = {pid: name for pid, name in unknown_fellows}


flat_options.append({
    'label': "Fellows of Unrecorded Nationality",
    'value': "Fellows of Unrecorded Nationality"
    })

#%% Creating a list of original fellows

original_fellows = [
    (node, G.nodes[node]["displayName"])
    for node in G.nodes()
    if G.nodes[node].get("membershiptype", '').strip() == "Original Fellow"
]


original_ids = [pid for pid, name in original_fellows]
original_labels = {pid: name for pid, name in original_fellows}

flat_options.append({
    'label': "Original Fellows",
    'value': "Original Fellows"
    })

#%% Creating a list of Fellows of the Fellow Membrship Type

fellow_fellows = [
    (node, G.nodes[node]["displayName"])
    for node in G.nodes()
    if G.nodes[node].get("membershiptype", '').strip() == "Fellow"
]

ff_ids = [pid for pid, mane in fellow_fellows]
ff_labels = {pid: name for pid, name in fellow_fellows}

flat_options.append({
    'label': "Typical Fellows",
    'value': "Typical Fellows"
    })

#%% Reordering flat_options for display

def reorder_flat_options(flat_options):
    preferred_order = [
        "Founders",
        "Foreign Fellows",
        "Domestic Fellows",
        "Fellows of Unrecorded Nationality",
        "Typical Fellows",
        "Original Fellows"
    ]

    # Create a lookup
    option_lookup = {opt["value"]: opt for opt in flat_options}

    # Pull the preferred ones to the front in the desired order
    ordered = [option_lookup[val] for val in preferred_order if val in option_lookup]

    # Add the rest (e.g., individual fellows), preserving original order
    remaining = [opt for opt in flat_options if opt["value"] not in preferred_order]

    return ordered + remaining

flat_options = reorder_flat_options(flat_options)

#%% Preparing for Cytoscape
# Build Cytoscape elements

elements = []
TEST = 'Sloane_Sir_Hans_1660_1753'  # change to a node you know has gens

for n, data in G.nodes(data=True):
   

    # Base node payload
    node_data = {
        'id':            n, 
        'nodeid':        n,
        'label':     data.get('displayName', n),
        'displayName':  data.get('displayName', n),
        'date':      dates[n].date().isoformat(),
        'name':      data.get('name',      'Unknown'),
        'EMLOid':    data.get('EMLOid',    'Unknown'),
        'RScode':    data.get('RScode',    'Unknown'),
        'indegree':  data.get('indegree',  'Unknown'),
        'outdegree': data.get('outdegree', 'Unknown'),
        'genlength': data.get('genlength', 'Unknown'),
        'totaldesc': data.get('totaldesc', 'Unknown'),
        'totalance': data.get('totalance', 'Unknown'),
        'rawID':     str(n), 
        'nationality': data.get('nationality', 'Unknown'), 
        "membershiptype": data.get('membershiptype', 'Unknown')
    }

    # Automatically catch any per-generation lists
    for attr, val in data.items():
        # If it's a string repr of a list, try parsing it
        if isinstance(val, str) and val.startswith('[') and val.endswith(']'):
            try:
                parsed = ast.literal_eval(val)
                val = parsed
            except Exception:
                pass

        # Now if it’s truly a Python list and non-empty, include it
        if isinstance(val, list) and val:
        
            node_data[attr] = val

    elements.append({
        'data':     node_data,
        'position': pos.get(n, {'x': 0, 'y': 0})
    })

# Add edges
for u, v in G.edges():
    elements.append({'data': {'source': u, 'target': v}})
    

# Stylesheet

base_stylesheet = [
    {'selector': 'node', 'style': {'label': 'data(displayName)', 'width': 1000, 'height': 1000, 'font-size': 10, 'background-color': '#052449'}},
    {'selector': 'edge', 'style': {'line-color': '#052449', 'width': 120, 'target-arrow-shape': 'triangle', 'target-arrow-color': '#888', 'arrow-scale': 1.2}},
    {'selector': ':selected', 'style': {'background-color': '#052449', 'line-color': '#052449', 'target-arrow-color': '#052449', 'border-width': 2, 'border-color': '#555'}}
]
#%%

# Dash App\ń#
cyto.load_extra_layouts()
app = dash.Dash(__name__)


app.layout = html.Div([
    html.H2("Royal Society Genealogy Explorer"),
    

   # Search dropdown at top

    dcc.Dropdown(
        id='node-search',
        options=flat_options,
        placeholder='Search or select a member or group…',
        searchable=True,
        style={'margin': '10px 0'}
    ),


    # Wrapper for graph and floating info panel
    html.Div([
        cyto.Cytoscape(
            id='cytograph',
            elements=elements,
            layout={
                'name': 'dagre',
                'rankDir': 'TB',
                'nodeSep': 400,
                'rankSep': 8000,
                'edgeSep': 10,
                'ranker': 'network-simplex',
                'fit': True,
                'padding': 30,
                'nodeDimensionsIncludeLabels': True
            },
            style={'width': '100%', 
                   'height': '800px',
                   'backgroundColor': 'transparent'},
            stylesheet=base_stylesheet
        ),

        html.Div(
            id='info-panel',
            children="Click or search for a fellow to see details here.",
            style={
                'position': 'absolute',
                'top': '20px',
                'right': '20px',
                'width': '250px',
                'maxHeight': '400px',
                'overflowY': 'auto',
                'backgroundColor': 'rgba(255,255,255,0.9)',
                'padding': '10px',
                'borderRadius': '4px',
                'boxShadow': '0 2px 8px rgba(0,0,0,0.3)',
                'zIndex': 999
            }
        )
    ], style={
        'position': 'relative',
        'width': '100%',
        'height': '800px',
        'backgroundColor': '#5b7da7'
    })
])

# Callbacks

@app.callback(
    [
        Output('cytograph', 'stylesheet'),
        Output('info-panel', 'children'),
        Output('node-search', 'value'), 
        Output('cytograph', 'selectedNodeData') 
    ],
    [
        Input('cytograph', 'tapNodeData'),
        Input('node-search', 'value')
    ]
)
def update_highlight(tap_data, search_value):
    # Debug prints
    # print("🔥 callback fired! tap_data =", tap_data)
    # print("🔥 search_value =", search_value)
    
    # 🔧 build displayName → node ID map up-front
    label_to_id = {data['displayName']: nid for nid, data in G.nodes(data=True)}
    
    # 🔧 use callback_context to see what triggered us
    ctx = dash.callback_context
    triggered = ctx.triggered[0]['prop_id'] if ctx.triggered else None
    
    if triggered and triggered.startswith('cytograph'):
        search_value = None

    chosen = None
    
    if triggered and triggered.startswith('node-search') and search_value:
        if search_value in president_terms \
           or search_value in secretary_terms \
           or search_value == "Founders" \
           or search_value == "Foreign Fellows" \
           or search_value == "Domestic Fellows" \
           or search_value == "Fellows of Unrecorded Nationality" \
           or search_value == "Typical Fellows"\
           or search_value == "Original Fellows":
            chosen = search_value
    
    elif triggered and triggered.startswith('node-search') and search_value:
        # now handle the normal node lookups
        if search_value in G.nodes():
            chosen = search_value
        elif search_value in label_to_id:
            chosen = label_to_id[search_value]
            
    elif triggered and triggered.startswith('cytograph') and tap_data:
        chosen = tap_data['id']


    comp, prop = (triggered.split('.', 1) + [None])[:2]

    
    clear_sel = [] if triggered.startswith('node-search') else no_update
    
    # 🔧 If the graph click triggered, clear dropdown selection
    if comp == 'cytograph':
        search_value = None                  # 🔧 override dropdown to prevent holdover


    if comp == 'node-search' and prop == 'value' and search_value:
        # dropdown fired
        if search_value in G.nodes():
            chosen = search_value                # use node id directly
        elif search_value in label_to_id:
            chosen = label_to_id[search_value]  # convert displayName to id
    elif comp == 'cytograph' and prop == 'tapNodeData' and tap_data:
        # graph click fired
        chosen = tap_data.get('id') 
    
    
    # Common info-panel style
    info_panel_style = {
        'fontSize': '14px',
        'lineHeight': '1.4em',
        'overflowY': 'auto',
        'maxHeight': '400px'
    }
    
    # Start from base stylesheet
    ss = list(base_stylesheet)
        
    #  — If no valid selection, return defaults
    if not chosen:
        default_info = html.P("Click or search for a fellow to see details here.")
        return ss, default_info, None, clear_sel

    # 1) Group: presidency cohorts
    if chosen in president_terms:
        pid = president_names[chosen]
        ss.append({
            'selector': f'[id="{pid}"]', 
            'style':    {'background-color': '#168ab7'}})
        members = president_terms[chosen]
        for m in members:
            ss.append({
                'selector': f'[id="{m}"]',
                'style':    {'background-color':'#f0c319'}
            })
            
        display_names = [G.nodes[m].get('displayName', m)for m in members]
        
        info_panel = html.Div([
            html.H4(chosen),
            html.P(f"{len(members)} fellows elected in this term."),
            html.Ul([html.Li(name) for name in display_names])
       ], style=info_panel_style)

        return ss, info_panel, search_value, clear_sel

    # 1.1) Group: secretary cohorts
    if chosen in secretary_terms:
        pid = secretary_names[chosen]
        ss.append({
            'selector': f'[id="{pid}"]', 
            'style':    {'background-color': '#168ab7'}})
        members = secretary_terms[chosen]
        for m in members:
            ss.append({
                'selector': f'[id="{m}"]',
                'style':    {'background-color':'#f0c319'}
            })
            
        display_names = [G.nodes[m].get('displayName', m)for m in members]
        
        info_panel = html.Div([
            html.H4(chosen),
            html.P(f"{len(members)} fellows elected in this term."),
            html.Ul([html.Li(name) for name in display_names])
       ], style=info_panel_style)

        return ss, info_panel, search_value, clear_sel

    # 1.2) Group: Founders
    if chosen == "Founders":
        # highlight each founder node in yellow
        for m in founder_ids:
            ss.append({
                'selector': f'[id="{m}"]',
                'style':    {'background-color':'#f0c319'}
            })
        display_names = [ G.nodes[m]['displayName'] for m in founder_ids ]
        # build a little info panel
        info_panel = html.Div([
            html.H4("Founders"),
            html.P(f"{len(founder_ids)} founding fellows."),
            html.Ul([ html.Li(name) for name in display_names ])
        ], style=info_panel_style)
        return ss, info_panel, search_value, clear_sel
    
    # 1.3) Group: Foreign Fellows 
    if chosen == "Foreign Fellows": 
        for m in foreign_ids: 
            ss.append({
                'selector':f'[id="{m}"]',
                'style':    {'background-color': '#f0c319'}
                })
        display_names = [f"{G.nodes[m]['displayName']} ({G.nodes[m]['nationality']})" for m in foreign_ids]
        info_panel = html.Div([
            html.H4("Foreign Fellows"),
            html.P(f"{len(foreign_ids)} foreign fellows."),
            html.Ul([html.Li(name) for name in display_names])
        ], style=info_panel_style)
        return ss, info_panel, search_value, clear_sel
    
    # 1.4) Group: Domestic Fellows
    if chosen == "Domestic Fellows":
        for m in domestic_ids: 
            ss.append({
                'selector': f'[id="{m}"]',
                'style':    {'background-color': '#f0c319'}
                })
        display_names = [f"{G.nodes[m]['displayName']} ({G.nodes[m]['nationality']})" for m in domestic_ids]
        info_panel = html.Div([
            html.H4("Domestic Fellows"),
            html.P(f"{len(domestic_ids)} domestic fellows."),
            html.Ul([html.Li(name) for name in display_names])
        ], style=info_panel_style)
        return ss, info_panel, search_value, clear_sel
    
    # 1.5) Group: Fellows of Unknown Nationality
    if chosen == "Fellows of Unrecorded Nationality": 
        for m in unknown_ids: 
            ss.append({
                'selector': f'[id="{m}"]', 
                'style': {'background-color': '#f0c319'}
                })
        display_names = [f"{G.nodes[m]['displayName']}" for m in unknown_ids]
        info_panel = html.Div([
            html.H4("Fellows of Unrecorded Nationality"),
            html.P(f"{len(ff_ids)} fellows of unrecorded nationality."),
            html.Ul([html.Li(name) for name in display_names])
        ], style=info_panel_style)
        return ss, info_panel, search_value, clear_sel
    
    # 1.6) Group: Typical Fellows
    if chosen == "Typical Fellows":
        for m in ff_ids: 
            ss.append({
                'selector': f'[id="{m}"]', 
                'style': {'background-color': '#f0c319'}
                })
        display_names = [f"{G.nodes[m]['displayName']}" for m in ff_ids]
        info_panel = html.Div([
            html.H4("Typical Fellows"),
            html.P(f"{len(ff_ids)} typical fellows."),
            html.Ul([html.Li(name) for name in display_names])
        ], style=info_panel_style)
        return ss, info_panel, search_value, clear_sel
    
    # 1.7) Group: Original Fellows
    if chosen == "Original Fellows":
        for m in original_ids:
            ss.append({
                'selector': f'[id="{m}"]', 
                'style': {'background-color': '#f0c319'}
                })
        display_names = [f"{G.nodes[m]['displayName']}" for m in original_ids]
        info_panel = html.Div([
            html.H4("Original Fellows"),
            html.P(f"{len(original_ids)} original fellows."),
            html.Ul([html.Li(name) for name in display_names])
        ], style=info_panel_style)
        return ss, info_panel, search_value, clear_sel

    # 2) Individual node: build payload from dropdown or click
    payload = {}
    if search_value:
        payload = dict(G.nodes[chosen])
        payload['id'] = chosen
    elif tap_data:
        payload = tap_data

    
    # Highlight node and its ancestors/descendants
    if chosen in G.nodes():
        # Node highlight
        ss.append({
            'selector': f'[id="{chosen}"]',
            'style':    {'background-color':'#168ab7'}
        })
        # Ancestors
        for a in nx.ancestors(G, chosen):
            ss.append({
                'selector': f'[id="{a}"]',
                'style':    {'background-color':'#cb1142'}
            })
        # Descendants
        for d in nx.descendants(G, chosen):
            ss.append({
                'selector': f'[id="{d}"]',
                'style':    {'background-color':'#f0c319'}
            })
        # Edge highlights
        anc_set  = set(nx.ancestors(G, chosen)) | {chosen}
        desc_set = set(nx.descendants(G, chosen)) | {chosen}
        for u, v in G.edges():
            if u in anc_set and v in anc_set:
                ss.append({
                    'selector': f'edge[source="{u}"][target="{v}"]',
                    'style':    {'line-color':'#cb1142','target-arrow-color':'#cb1142','arrow-scale':1.2}
                })
            if u in desc_set and v in desc_set:
                ss.append({
                    'selector': f'edge[source="{u}"][target="{v}"]',
                    'style':    {'line-color':'#f0c319','target-arrow-color':'#f0c319','arrow-scale':1.2}
                })

    # 3) Build info panel for individual
    info_children = []
    if payload:
        # rawID      = payload.get('rawID', 'Unknown')
        # label      = payload.get('label', 'Unknown')
        name       = payload.get('name', 'Unknown')
        date       = payload.get('date', 'Unknown')
        RScode     = payload.get('RScode', 'Unknown')
        EMLOid     = payload.get('EMLOid', 'Unknown')
        indegree   = payload.get('indegree', 'Unknown')
        outdegree  = payload.get('outdegree', 'Unknown')
        genlength  = payload.get('genlength', 'Unknown')
        totaldesc  = payload.get('totaldesc', 'Unknown')
        totalance  = payload.get('totalance', 'Unknown')
        nationality = payload.get('nationality', 'Unknown')
        membershiptype = payload.get('membershiptype', 'Unknown')

        info_children = [
            html.H4(G.nodes[chosen]["displayName"]),
            html.P([html.Em("Royal Society Authorized Name: "),f"{name}"]),
            html.P([html.Em("Election date: "), f"{date}"]),
            html.P([html.Em("Member Type: "), f"{membershiptype}"]),
            html.P([html.Em("Nationality: "), f"{nationality}"]),
            html.P([html.Em("Royal Society ID: "), f"{RScode}"]),
            html.P([
                    html.Em("Profile: "),
                    html.A(
                        "View on the Royal Society Website",
                        href=f'https://catalogues.royalsociety.org/CalmView/Record.aspx?src=CalmView.Persons&id={RScode}',
                        target="_blank",     # open in new tab
                        rel="noopener noreferrer", 
                        style={'color': '#1f77b4', 'textDecoration': 'underline'}
                    )
                ]),
            html.P([html.Em("EMLO Person ID: "), f"{int(EMLOid)}"]),
            html.P([
                    html.Em("Profile: "),
                    html.A(
                        "View on EMLO",
                        href=f'http://emlo.bodleian.ox.ac.uk/p/{int(EMLOid)}',
                        target="_blank",     # open in new tab
                        rel="noopener noreferrer", 
                    )
                ]),
            html.P([html.Em("Number of Proposers: "), f"{indegree}"]),
            html.P([html.Em("Number Proposed: "), f"{outdegree}"]), 
            html.P([html.Em("Genealogy Depth: "), f"{genlength}"]),
            html.P([html.Em("Total Descendants: "), f"{totaldesc}"]),
            html.P([html.Em("Total Ancestors: "), f"{totalance}"]), 
            html.P([html.Em("App Internal ID: "), f"{chosen}"])
        ]
        for attr, val in list(payload.items()):
            if isinstance(val, str) and val.startswith('[') and val.endswith(']'):
                try:
                    parsed = ast.literal_eval(val)
                    if isinstance(parsed, list):
                        payload[attr] = parsed
                except (ValueError, SyntaxError):
                    # not a real Python list repr; leave it alone
                    pass
        for attr, val in payload.items():
            if isinstance(val, list) and val:
                # pretty = attr.replace('gendesc','-Gen Descendants').replace('genanc','-Gen Ancestors')
                pretty_list = []
                for member in val: 
                    val_name = G.nodes[member]["displayName"]
                    pretty_list.append(val_name)
                info_children.append(html.P([html.Em(f"{attr}: "), f"{'; '.join(pretty_list)}"]))
    else:
        info_children = [html.P("Click or search a fellow to see details here.")]

    info_panel = html.Div(info_children, style=info_panel_style)
    
    
    return ss, info_panel, search_value, clear_sel     # CHANGED: return the third output


# Run
if __name__ == '__main__':
    app.run(debug=False, host='0.0.0.0', port=8050)
