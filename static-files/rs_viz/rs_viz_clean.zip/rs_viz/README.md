This is a Dash-Cytospace app called the "Royal Society Genealogy Explorer." It is intended for use by historians of the Early Modern period and other academics interested in the formation and social dynamics of the early Royal Society. 

The app requires dash, dash_cytoscape, and pandas to run along with some built in python packages. More details are included in requirements.txt. The relevant dependencies can be installed by running "pip install -r requirements.txt". 

The data folder should include five csv files of data, cleaned and organized to accommodate different app functions. They should be named as follows: 
- Public_Complete_RS_Graph_Metrics_MetaData.csv (graph statistics about individual Fellows)
- Public_RS_data_cleanMembershipColumn.csv (the full data printout with a cleaned rsactivity column and added information columns)
- Public_RS_data_ConfirmedMatches.csv (list of confirmed Fellow-proposer matches and columsn with each state of the cleaning process)
- Public_RS_Graph_Metrics_MetaData_with_Office_Data.csv (graph metrics that include data about offices held)
- Public_RS_Proposer_Data_Cleaned&Graphable.csv (proposer data specifically cleaned for the graph geneation function within the app)


The assets folder should include the css style sheet. 

The app has been dockerized and should be ready for web deployment.

Credits: 
The greatest thanks for this project go to Miranda Lewis, EMLO’s editor. She supported every aspect of the project and guided me through working to build a tool for the exploration of material that was unfamiliar to me and far from my specialism. 

The data procurement and preparation for this project is credited to Louisiane Ferlier (Digital Resources Manager at the Royal Society) and John Pybus (Developer, EMLO, at the Oxford e-Research Centre, Oxford). Louisiane Ferlier provided the data from the Royal Society’s own files in XML format and John Pybus migrated the data from an XML to Excel format. 

John Pybus also ensured the Royal Society Genealogy Explorer’s successful integration into the EMLO text page. 

Philip Beeley (Research Fellow and Tutor at the University of Oxford History Faculty) provided expert advice and made recommendations on how to make the tool most useful to historians of early modern science. 

Millie Gall (Editorial and Administrative Assistant, EMLO) proofread and suggested edits on drafts of this page.

ChatGPT (versions 4o, o3, and o4-mini-high) assisted in writing and producing code for the Genealogy Explorer itself as well as the visualizations on this page. 



